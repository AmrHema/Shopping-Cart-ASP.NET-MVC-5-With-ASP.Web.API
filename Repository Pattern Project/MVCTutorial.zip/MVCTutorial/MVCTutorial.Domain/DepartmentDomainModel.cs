﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVCTutorial.Domain
{
    public class DepartmentDomainModel
    {
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }
    
    }
}
